export const isAuthDisabled = process.env.AUTH_DISABLED === 'true'
